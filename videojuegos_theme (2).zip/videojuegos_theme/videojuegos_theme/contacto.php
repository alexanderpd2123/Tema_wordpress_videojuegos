<?php
/*
Template Name: Contacto
*/
get_header();
?>

<main class="contacto-main">
  <h2 class="contacto-titulo">CONTACTO</h2>
  <div class="contacto-form-container">
    <form class="contacto-form" method="post" action="">
      <label for="nombre">Nombre</label>
      <input type="text" id="nombre" name="nombre" placeholder="Value" required>
      
      <label for="apellido">Apellido</label>
      <input type="text" id="apellido" name="apellido" placeholder="Value" required>
      
      <label for="email">Email</label>
      <input type="email" id="email" name="email" placeholder="Value" required>
      
      <label for="mensaje">Mensaje</label>
      <textarea id="mensaje" name="mensaje" placeholder="Value" rows="3" required></textarea>
      
      <button type="submit">Submit</button>
    </form>
  </div>
</main>

<?php get_footer(); ?>
