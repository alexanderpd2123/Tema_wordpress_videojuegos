<?php
// Archivo básico index.php necesario para cualquier tema
get_header();
echo "<main><h2>Bienvenido al tema</h2></main>";
get_footer();
?>
