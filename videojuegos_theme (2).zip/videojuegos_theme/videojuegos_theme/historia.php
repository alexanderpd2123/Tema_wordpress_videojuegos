<?php
/*
Template Name: Historia
*/
get_header();
?>
<main class="historia-main">
  <h2 class="historia-titulo">Historia PS2</h2>
  <div class="historia-contenido">
    <p>
      La PlayStation 2 es la consola de sobremesa más vendida de la historia y marcó una época en el mundo de los videojuegos. Se lanzó el 4 de marzo del año 2000 en Japón y meses después en el resto del mundo, convirtiéndose rápidamente en un éxito de ventas y de innovación tecnológica.
    </p>
    <b>Orígenes y desarrollo</b>
    <p>
      Sony anunció oficialmente la PlayStation 2 en marzo de 1999, prometiendo una máquina revolucionaria con un procesador "Emotion Engine" de 128 bits y grandes capacidades gráficas. Esto generó enorme expectación, y las primeras demos técnicas mostraron avances sorprendentes para la época.
    </p>
    <b>Lanzamiento y recepción</b>
    <p>
      La consola debutó el 4 de marzo de 2000 en Japón, causando enormes colas y escasez inicial de unidades. Su éxito en Japón, y después en Europa y Norteamérica, fue uno de los más grandes de la época, vendiendo cerca de un millón de unidades en Japón, y alcanzando récords mundiales.
    </p>
    <b>Legado y características</b>
    <p>
      La PS2 ofrecía retrocompatibilidad con los juegos de PlayStation original, soporte de DVD y un catálogo inmenso y muy influyente (GTA, Final Fantasy, Gran Turismo, Jak y muchos otros). Su longevidad, servicio de juegos en línea y periféricos variados consolidaron su producción durante más de 12 años, hasta ser superada por la siguiente generación de consolas (PS3, PS4, PS5).
    </p>
    <p>
      Gracias a sus avances técnicos y enorme catálogo, la PlayStation 2 es un icono, y una de las piezas clave del desarrollo de la industria de videojuegos y lleva el entretenimiento digital a nuevas generaciones.
    </p>
    <div class="historia-img-wrap">
      <img src="<?php echo get_template_directory_uri(); ?>/images/ps2mandos.jpg" alt="PlayStation 2 con mandos" class="historia-img">
    </div>
  </div>
</main>
<?php get_footer(); ?>
