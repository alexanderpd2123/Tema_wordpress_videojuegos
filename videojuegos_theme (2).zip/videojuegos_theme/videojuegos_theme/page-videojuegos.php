<?php
/*
Template Name: Videojuegos
*/
get_header();
?>
<main class="listado-Videojuegos">
  <h1>Videojuegos</h1>
  <div class="grid-Videojuegos">
    <?php
    $args = array(
      'post_type' => 'Videojuegos', 
      'posts_per_page' => 18,
      'paged' => get_query_var('paged') ? get_query_var('paged') : 1
    );
    $videojuegos = new WP_Query($args);
    if ($videojuegos->have_posts()):
      while ($videojuegos->have_posts()): $videojuegos->the_post();
        $img = get_field('imagen-juego');
        $img_url = is_array($img) ? $img['url'] : $img;
        if (!$img_url) $img_url = get_template_directory_uri() . '/images/default-cover.jpg';
        $gameplay = get_field('gamplay'); 
    ?>
      <div class="Videojuego-bloque">
        <a href="<?php the_permalink(); ?>">
          <img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>" class="videojuego-portada">
        </a>
        <div class="Videojuego-nombre"><?php the_title(); ?></div>
        <div class="Videojuego-extracto"><?php echo wp_trim_words(get_the_content(), 18, '...'); ?></div>
        <?php if ($gameplay): ?>
          <div class="gameplay-video">
            <?php echo wp_oembed_get($gameplay); ?>
          </div>
        <?php endif; ?>
      </div>
    <?php
      endwhile;
      wp_reset_postdata();
    else:
      echo '<p>No hay videojuegos.</p>';
    endif;
    ?>
  </div>
  <?php the_posts_pagination(); ?>
</main>
<?php get_footer(); ?>
