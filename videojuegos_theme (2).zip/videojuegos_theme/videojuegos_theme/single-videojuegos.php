<?php get_header(); ?>
<main class="juego-main">
  <h2 class="juego-titulo">
    <?php the_title(); ?>
    <span class="juego-categorias">
      <?php
      $terms = get_the_terms(get_the_ID(), 'categoria');
      if ($terms && !is_wp_error($terms)) {
        echo ' – ' . esc_html(implode(', ', wp_list_pluck($terms, 'name')));
      }
      ?>
    </span>
  </h2>

  <div class="juego-ficha">
    <div class="juego-portada-wrap">
      <?php
      $img = get_field('imagen-juego');
      $img_url = is_array($img) ? $img['url'] : $img;
      if ($img_url) {
        echo '<img src="'.esc_url($img_url).'" alt="'.esc_attr(get_the_title()).'" class="juego-portada-individual">';
      }
      ?>
    </div>

    <div class="juego-meta">
      <?php if(get_field('desarrollador')): ?>
        Desarrollador: <?php the_field('desarrollador'); ?><br>
      <?php endif; ?>
      <?php if(get_field('distribuidor')): ?>
        Distribuidor: <?php the_field('distribuidor'); ?><br>
      <?php endif; ?>
      <?php if(get_field('plataformas')): ?>
        Plataformas: <?php the_field('plataformas'); ?><br>
      <?php endif; ?>
      <?php if(get_field('genero')): ?>
        Género: <?php the_field('genero'); ?><br>
      <?php endif; ?>
      <?php if(get_field('lanzamiento')): ?>
        Lanzamiento: <?php the_field('lanzamiento'); ?><br>
      <?php endif; ?>
    </div>

    <div class="juego-descripcion-ficha"> 
      <?php the_content(); ?>
    </div>

    <?php
    $video = get_field('gamplay'); 
    if ($video) {
      echo '<div class="gamplay">' . wp_oembed_get($video) . '</div>';
    } else {
      echo '<p style="color:red;">No hay video guardado en el campo gamplay para este juego.</p>';
    }
    ?>
  </div>

  <div class="juego-comentarios">
    <?php comments_template(); ?>
  </div>
</main>
<?php get_footer(); ?>
