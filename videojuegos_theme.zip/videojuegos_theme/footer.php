  <footer class="footer-section">
    <div class="contacto">
      <h3>Contacto</h3>
      <span>Facebook</span>
      <span>Twitter</span>
      <span>Instagram</span>
    </div>
    <div class="legal">
      <h3>Legal</h3>
      <p>Términos y condiciones</p>
    </div>
  </footer>
  <?php wp_footer(); ?>
</body>
</html>
