<?php get_header(); ?>

<main class="main-portada">
  <h1>Juegos de la época</h1>

  <!-- Juegos destacados -->
  <section>
    <h2>Juegos destacados</h2>
    <div class="grid-juegos">
      <?php
      $destacados = new WP_Query(array(
        'post_type' => 'videojuegos', // O cambia a 'videojuegos' según tu CPT real
        'posts_per_page' => 4,
        // Puedes usar meta_query o tax_query para filtrar destacados si tienes un campo, si no saca los últimos
      ));
      if ($destacados->have_posts()) :
        while ($destacados->have_posts()) : $destacados->the_post();
          $img_portada = get_field('imagen-juego');
          $img_url = is_array($img_portada) ? $img_portada['url'] : $img_portada;
          if (!$img_url) $img_url = get_template_directory_uri() . '/images/default-cover.jpg';
          ?>
          <div class="juego-item">
            <a href="<?php the_permalink(); ?>">
              <img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
            </a>
            <div class="juego-nombre"><?php the_title(); ?></div>
          </div>
          <?php
        endwhile;
        wp_reset_postdata();
      endif;
      ?>
    </div>
  </section>

  <!-- Agregados recientemente -->
  <section>
    <h2>Agregados recientemente</h2>
    <div class="grid-juegos">
      <?php
      $recientes = new WP_Query(array(
        'post_type' => 'videojuegos', // O cambia a 'videojuegos' según tu CPT real
        'posts_per_page' => 4,
        'orderby' => 'date',
        'order' => 'DESC'
      ));
      if ($recientes->have_posts()) :
        while ($recientes->have_posts()) : $recientes->the_post();
          $img_portada = get_field('imagen-juego');
          $img_url = is_array($img_portada) ? $img_portada['url'] : $img_portada;
          if (!$img_url) $img_url = get_template_directory_uri() . '/images/default-cover.jpg';
          ?>
          <div class="juego-item">
            <a href="<?php the_permalink(); ?>">
              <img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
            </a>
            <div class="juego-nombre"><?php the_title(); ?></div>
          </div>
          <?php
        endwhile;
        wp_reset_postdata();
      endif;
      ?>
    </div>
  </section>

  <!-- Mods destacados (puedes cambiar la consulta para que sólo saque Mods si tienes una taxonomía para eso) -->
  <section>
    <h2>Mods destacados</h2>
    <div class="grid-juegos">
      <?php
      $mods = new WP_Query(array(
        'post_type' => 'videojuegos', // O cambia a 'videojuegos'
        'posts_per_page' => 4,
        // Aquí puedes usar 'tax_query' con la categoría o campo que uses para detectar mods
      ));
      if ($mods->have_posts()) :
        while ($mods->have_posts()) : $mods->the_post();
          $img_portada = get_field('imagen-juego');
          $img_url = is_array($img_portada) ? $img_portada['url'] : $img_portada;
          if (!$img_url) $img_url = get_template_directory_uri() . '/images/default-cover.jpg';
          ?>
          <div class="juego-item">
            <a href="<?php the_permalink(); ?>">
              <img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>">
            </a>
            <div class="juego-nombre"><?php the_title(); ?></div>
          </div>
          <?php
        endwhile;
        wp_reset_postdata();
      endif;
      ?>
    </div>
  </section>
</main>

<?php get_footer(); ?>

