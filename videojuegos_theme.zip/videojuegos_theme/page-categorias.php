<?php
/*
Template Name: Categorías
*/
get_header();
?>
<main class="categorias-page">
  <h2 class="titulo-categorias">Pagina Categorias</h2>
  <div class="categorias-grid">
    <!-- Acción -->
    <div class="categoria-bloque">
      <div class="titulo-cat">Accion</div>
      <a href="<?php echo home_url('/accion'); ?>">
        <img src="<?php echo get_template_directory_uri(); ?>/images/accion.jpg" alt="Acción" class="portada-cat">
      </a>
    </div>
    <!-- Deportes -->
    <div class="categoria-bloque">
      <div class="titulo-cat">Deportes</div>
      <a href="<?php echo home_url('/deportes'); ?>">
        <img src="<?php echo get_template_directory_uri(); ?>/images/deportes.jpg" alt="Deportes" class="portada-cat">
      </a>
    </div>
    <!-- Terror -->
    <div class="categoria-bloque">
      <div class="titulo-cat">Terror</div>
      <a href="<?php echo home_url('/terror'); ?>">
        <img src="<?php echo get_template_directory_uri(); ?>/images/terror.jpg" alt="Terror" class="portada-cat">
      </a>
    </div>
    <!-- Retro -->
    <div class="categoria-bloque">
      <div class="titulo-cat">Retro</div>
      <a href="<?php echo home_url('/retro'); ?>">
        <img src="<?php echo get_template_directory_uri(); ?>/images/retro.jpg" alt="Retro" class="portada-cat">
      </a>
    </div>
  </div>
</main>
<?php get_footer(); ?>
