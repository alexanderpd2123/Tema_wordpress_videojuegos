<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php bloginfo('name'); ?></title>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="site-header">
  <div class="logo-titulo">
    <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="Logo" class="logo">
    <span class="titulo-principal">Juegos de la época</span>
  </div>
  <nav class="menu">
    <a href="<?php echo esc_url(home_url("/")); ?>">Inicio</a>
    <a href="<?php echo esc_url(home_url("/noticias")); ?>">Noticias</a>
    <a href="<?php echo esc_url(home_url("/Categorias")); ?>">Juegos</a>
    <a href="<?php echo esc_url(home_url("/historia")); ?>">Historia</a>
    <a href="<?php echo esc_url(home_url("/consola")); ?>">Consola</a>
    <a href="<?php echo esc_url(home_url("/contacto")); ?>">Contacto</a>
  </nav>

</header>
