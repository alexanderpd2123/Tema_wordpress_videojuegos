<?php
/*
Template Name: Terror
*/
get_header();
?>
<main class="terror-main">
  <h2 class="terror-titulo">Terror</h2>
  <div class="terror-grid">
    <?php
    $args = array(
      'post_type' => 'videojuegos', // Cambia por 'videojuegos' solo si así se llama tu CPT
      'tax_query' => array(
        array(
          'taxonomy' => 'categoria',
          'field'    => 'slug',
          'terms'    => 'terror',
        ),
      ),
      'posts_per_page' => 18,
    );
    $juegos = new WP_Query($args);
    if ($juegos->have_posts()) :
      while ($juegos->have_posts()) : $juegos->the_post();
        $img_portada = get_field('imagen-juego'); // tu campo ACF
        $img_url = is_array($img_portada) ? $img_portada['url'] : $img_portada;
        if (!$img_url) $img_url = get_template_directory_uri() . '/images/default-cover.jpg';
        ?>
        <div class="terror-bloque">
          <a href="<?php the_permalink(); ?>">
            <img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>" class="terror-portada">
          </a>
          <div class="terror-nombre"><?php the_title(); ?></div>
        </div>
        <?php
      endwhile;
      wp_reset_postdata();
    else :
      echo '<p class="no-juegos">No hay juegos de terror.</p>';
    endif;
    ?>
  </div>
</main>
<?php get_footer(); ?>

