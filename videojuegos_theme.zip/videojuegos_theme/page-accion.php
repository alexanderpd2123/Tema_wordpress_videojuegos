<?php
/*
Template Name: Acción
*/
get_header();
?>
<main class="accion-main">
  <h2 class="accion-titulo">Accion</h2>
  <div class="accion-grid">
    <?php
    $args = array(
      'post_type' => 'videojuegos', // nombre real de tu CPT
      'tax_query' => array(
        array(
          'taxonomy' => 'categoria',
          'field'    => 'slug',
          'terms'    => 'accion',
        ),
      ),
      'posts_per_page' => 18,
    );
    $juegos = new WP_Query($args);
    if ($juegos->have_posts()) :
      while ($juegos->have_posts()) : $juegos->the_post();
        $img_portada = get_field('imagen-juego');
        $img_url = is_array($img_portada) ? $img_portada['url'] : $img_portada;
        if (!$img_url) {
          $img_url = get_template_directory_uri() . '/images/default-cover.jpg';
        }
        ?>
        <div class="juego-bloque">
          <a href="<?php the_permalink(); ?>">
            <img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>" class="juego-portada">
          </a>
          <div class="juego-nombre"><?php the_title(); ?></div>
        </div>
        <?php
      endwhile; wp_reset_postdata();
    else:
      echo "<p>No hay videojuegos en esta categoría.</p>";
    endif;
    ?>
  </div>
</main>
<?php get_footer(); ?>

