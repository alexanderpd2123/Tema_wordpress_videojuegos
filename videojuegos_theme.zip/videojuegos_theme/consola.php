<?php
/*
Template Name: Consola
*/
get_header();
?>
<main class="consola-main">
  <h2 class="consola-titulo">La Consola</h2>
  <div class="consola-img-wrap">
    <img src="<?php echo get_template_directory_uri(); ?>/images/ps2.jpg" alt="PlayStation 2" class="consola-img">
  </div>
  <div class="consola-info">
    <p>
      La PlayStation 2 (PS2) es una consola de videojuegos icónica lanzada por Sony en el año 2000, reconocida por su arquitectura avanzada y su enorme catálogo de juegos.<br>
      <b>Especificaciones Técnicas</b>
    </p>
    <ul>
      <li>Procesador: MIPS R5900 Emotion Engine de 128 bits, frecuencia de 294.912 MHz (algunos modelos llegan a 299 MHz).</li>
      <li>Memoria principal: 32 MB RDRAM tipo Rambus, ancho de banda de 128 bits.</li>
      <li>Procesador gráfico: Graphics Synthesizer a 147 MHz, con 4 MB de memoria interna VRAM.</li>
      <li>Capacidad gráfica: Hasta 66 millones de polígonos por segundo (teórico), 55 GFLOPS en rendimiento de coma flotante.</li>
      <li>Unidad de almacenamiento: Lectura de discos DVD-ROM (juegos y películas) y CD-ROM, soporte para disco duro IDE (edición fat) y tarjetas de memoria.</li>
      <li>Audio: 48 canales de audio, compatible con salida Dolby Digital 5.1 y DTS, con memoria dedicada de 2 MB.</li>
      <li>Digital I/O, 5 puertos AC3, dos conectores estándar para controlador, dos puertos USB, IEEE-1394 (FireWire), entrada y salida AV, salida S-Video y digital, entrada de red.</li>
      <li>Soporte de mandos DualShock 2 y 2 periféricos con sensores de movimiento.</li>
      <li>Formatos soportados: MPEG2 y videojuegos, soporte para reproducción de vídeo, datos de audio y CD.</li>
      <li>Compatibilidad: La mayoría de modelos son retrocompatibles con juegos y accesorios de PlayStation (PSX).</li>
      <li>Color: Negro o plata, con diferentes revisiones, y es el sistema más vendido de la historia.</li>
    </ul>
    <p>
      La consola PS2 fue famosa por su variedad de accesorios, y es original en su retrocompatibilidad con juegos de PlayStation original.
    </p>
  </div>
</main>
<?php get_footer(); ?>
