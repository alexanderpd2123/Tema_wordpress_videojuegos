<?php
// Menú principal
function registrar_menus_tema() {
    register_nav_menus(array(
        'menu-principal' => __('Menú principal'),
    ));
}
add_action('init', 'registrar_menus_tema');




// TAXONOMÍA "categoria" para "videojuego"
function registrar_taxonomia_categoria_videojuegos() {
    $labels = array(
        'name'          => "Categorias",
        'singular_name' => "Categoria",
        'search_items'  => "Buscar Categorias",
        'all_items'     => "Todas las Categorias",
        'edit_item'     => "Editar Categoria",
        'add_new_item'  => "Añadir Categoria",
        'menu_name'     => "Categorias"
    );
    $args = array(
        'labels'            => $labels,
        'hierarchical'      => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
        'rewrite'           => array('slug' => 'categoria'),
    );
    register_taxonomy('categoria', array('videojuegos'), $args);
}
add_action('init', 'registrar_taxonomia_categoria_videojuegos');

// Enlazar CSS y FontAwesome
function videojuegosThemes_styles() {
    wp_enqueue_style('style', get_stylesheet_uri());
    wp_enqueue_style('fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css', array(), '6.0.0-beta3');
}
add_action('wp_enqueue_scripts', 'videojuegosThemes_styles');
?>
