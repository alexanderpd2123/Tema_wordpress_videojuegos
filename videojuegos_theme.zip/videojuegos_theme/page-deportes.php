<?php
/*
Template Name: Deportes
*/
get_header();
?>
<main class="deportes-main">
  <h2 class="deportes-titulo">Deportes</h2>
  <div class="deportes-grid">
    <?php
    $args = array(
      'post_type' => 'videojuegos', // usa tu CPT real (cambia SOLO si tu CPT es 'videojuegos')
      'tax_query' => array(
        array(
          'taxonomy' => 'categoria',
          'field'    => 'slug',
          'terms'    => 'deportes',
        ),
      ),
      'posts_per_page' => 18,
    );
    $juegos = new WP_Query($args);
    if ($juegos->have_posts()) :
      while ($juegos->have_posts()) : $juegos->the_post();
        $img_portada = get_field('imagen-juego'); // tu campo imagen ACF
        $img_url = is_array($img_portada) ? $img_portada['url'] : $img_portada;
        if (!$img_url) $img_url = get_template_directory_uri() . '/images/default-cover.jpg';
        ?>
        <div class="deportes-bloque">
          <a href="<?php the_permalink(); ?>">
            <img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>" class="deportes-portada">
          </a>
          <div class="deportes-nombre"><?php the_title(); ?></div>
        </div>
        <?php
      endwhile;
      wp_reset_postdata();
    else :
      echo '<p class="no-juegos">No hay juegos de deportes.</p>';
    endif;
    ?>
  </div>
</main>
<?php get_footer(); ?>

