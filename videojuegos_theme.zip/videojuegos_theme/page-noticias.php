<?php
/*
Template Name: Noticias
*/
get_header();
?>

<main class="noticias-main">
  <h1 class="noticias-titulo">Noticias</h1>
  <div class="grid-noticias">
    <?php
      $args = array(
        'post_type' => 'Videojuegos', // Cambia el nombre si tu CPT es distinto
        'posts_per_page' => 10,
        'paged' => get_query_var('paged') ? get_query_var('paged') : 1
      );
      $videojuegos = new WP_Query($args);
      if ($videojuegos->have_posts()) :
        while ($videojuegos->have_posts()) : $videojuegos->the_post();
          echo '<div class="noticia-bloque">';
          echo '<div class="noticia-exclusiva">Noticia exclusiva</div>';
          $img = get_field('imagen-juego');
          if (is_array($img) && isset($img['url'])) {
            echo '<a href="' . get_permalink() . '"><img src="' . esc_url($img['url']) . '" alt="' . esc_attr(get_the_title()) . '" class="noticia-portada"></a>';
          }
          echo '<a href="' . get_permalink() . '"><h2 class="noticia-titulo">' . get_the_title() . '</h2></a>';
          echo '<div class="noticia-extracto">' . wp_trim_words(get_the_content(), 25, '...') . '</div>';
          echo '</div>';
        endwhile;
        wp_reset_postdata();
      else :
        echo '<p>No hay noticias disponibles.</p>';
      endif;
    ?>
  </div>
  <?php the_posts_pagination(); ?>
</main>

<?php get_footer(); ?>
