<?php
/*
    Plugin Name: Post Personalizado
    Description: Crear un post personalizado
    Version: 1.0.0
    Author: alexander
    Text Domain: noticias_$Alexander
*/

if(!defined('ABSPATH')) die();

// Registrar
function raycothemess_videojuegos_post_type() {

	$labels = array(
		'name'                  => _x( 'Videojuegos', 'Post Type General Name', 'noticias_$Alecander' ),
		'singular_name'         => _x( 'Videojuegos', 'Post Type Singular Name', 'noticias_$Alecander' ),
		'menu_name'             => __( 'Videojuegos', 'noticias_$Alecander' ),
		'name_admin_bar'        => __( 'Videojuegos', 'noticias_$Alecander' ),
		'archives'              => __( 'Archivo', 'noticias_$Alecander' ),
		'attributes'            => __( 'Atributos', 'noticias_$Alecander' ),
		'parent_item_colon'     => __( 'Videojuegos Padre', 'noticias_$Alecander' ),
		'all_items'             => __( 'Todas Las Videojuegos', 'noticias_$Alecander' ),
		'add_new_item'          => __( 'Agregar Videojuegos', 'noticias_$Alecander' ),
		'add_new'               => __( 'Agregar Videojuegos', 'noticias_$Alecander' ),
		'new_item'              => __( 'Nueva Videojuegos', 'noticias_$Alecander' ),
		'edit_item'             => __( 'Editar Videojuegos', 'noticias_$Alecander' ),
		'update_item'           => __( 'Actualizar Videojuegos', 'noticias_$Alecander' ),
		'view_item'             => __( 'Ver Videojuegos', 'noticias_$Alecander' ),
		'view_items'            => __( 'Ver Videojuegos', 'noticias_$Alecander' ),
		'search_items'          => __( 'Buscar Videojuegos', 'noticias_$Alecander' ),
		'not_found'             => __( 'No Encontrado', 'noticias_$Alecander' ),
		'not_found_in_trash'    => __( 'No Encontrado en Papelera', 'noticias_$Alecander' ),
		'featured_image'        => __( 'Imagen Destacada', 'noticias_$Alecander' ),
		'set_featured_image'    => __( 'Guardar Imagen destacada', 'noticias_$Alecander' ),
		'remove_featured_image' => __( 'Eliminar Imagen destacada', 'noticias_$Alecander' ),
		'use_featured_image'    => __( 'Utilizar como Imagen Destacada', 'noticias_$Alecander' ),
		'insert_into_item'      => __( 'Insertar en Videojuegos', 'noticias_$Alecander' ),
		'uploaded_to_this_item' => __( 'Agregado en Videojuegos', 'noticias_$Alecander' ),
		'items_list'            => __( 'Lista de Videojuegos', 'noticias_$Alecander' ),
		'items_list_navigation' => __( 'Navegación de Videojuegos', 'noticias_$Alecander' ),
		'filter_items_list'     => __( 'Filtrar Videojuegos', 'noticias_$Alecander' ),
	);
	$args = array(
		'label'                 => __( 'Videojuegos', 'noticias_$Alecander' ),
		'description'           => __( 'Videojuegos para el Sitio Web', 'noticias_$Alecander' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'hierarchical'          => true, // true = posts , false = paginas
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
        'menu_position'         => 6,
        'menu_icon'             => 'dashicons-welcome-learn-more',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'Videojuegos', $args );

}
add_action( 'init', 'raycothemess_Videojuegos_post_type', 0 );